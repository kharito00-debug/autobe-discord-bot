import { Client, GatewayIntentBits, REST, Routes } from 'discord.js';
import dotenv from 'dotenv';
import * as mergeCommand from './commands/merge';

dotenv.config();

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [mergeCommand.data.toJSON()];

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN!);

client.once('ready', async () => {
    console.log(`Logged in as ${client.user?.tag}!`);
    try {
        console.log('Started refreshing application (/) commands.');
        await rest.put(Routes.applicationCommands(process.env.CLIENT_ID!), { body: commands });
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'merge') {
        await mergeCommand.execute(interaction);
    }
});

client.login(process.env.DISCORD_TOKEN);