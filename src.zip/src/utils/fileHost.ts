import axios from 'axios';
import FormData from 'form-data';

export async function downloadFile(url: string): Promise<Buffer> {
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    return Buffer.from(response.data);
}

/**
 * Uploads a buffer to a temporary file host and returns a download URL.
 *
 * Host chain (tried in order):
 *   1. Litterbox (litterbox.catbox.moe) — anonymous, any extension, 72h expiry, plain-text URL response
 *   2. GoFile (gofile.io)               — anonymous, any extension, 10-day expiry, JSON response
 */
export async function uploadToHost(buffer: Buffer, filename: string): Promise<string> {

    // ── 1. Litterbox ──────────────────────────────────────────────────────────
    try {
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('time', '72h');
        form.append('fileToUpload', buffer, { filename });

        const response = await axios.post(
            'https://litterbox.catbox.moe/resources/internals/api.php',
            form,
            { headers: form.getHeaders(), maxBodyLength: Infinity, timeout: 90_000 }
        );

        // Litterbox returns the URL as plain text
        const url = (response.data as string).trim();
        if (url.startsWith('https://')) {
            return url;
        }
        throw new Error(`Litterbox returned unexpected response: ${url}`);
    } catch (err) {
        console.warn('[fileHost] Litterbox failed, trying GoFile:', (err as Error).message);
    }

    // ── 2. GoFile ─────────────────────────────────────────────────────────────
    try {
        // Step 1: pick the best available upload server
        const serverRes = await axios.get('https://api.gofile.io/servers', { timeout: 10_000 });
        const servers: { name: string }[] = serverRes.data?.data?.servers;
        if (!servers?.length) throw new Error('GoFile returned no servers');
        const server = servers[0].name; // e.g. "store1"

        // Step 2: upload the file
        const form = new FormData();
        form.append('file', buffer, { filename });

        const uploadRes = await axios.post(
            `https://${server}.gofile.io/contents/uploadfile`,
            form,
            { headers: form.getHeaders(), maxBodyLength: Infinity, timeout: 90_000 }
        );

        if (uploadRes.data?.status !== 'ok') {
            throw new Error(`GoFile upload failed: ${JSON.stringify(uploadRes.data)}`);
        }

        // Return the user-facing download page (direct link not available without auth)
        const downloadPage: string = uploadRes.data.data.downloadPage;
        return downloadPage;
    } catch (err) {
        console.warn('[fileHost] GoFile failed:', (err as Error).message);
    }

    // ── All hosts exhausted ───────────────────────────────────────────────────
    throw new Error(
        'All upload hosts failed (Litterbox, GoFile). ' +
        'Please try again in a moment or upload the file manually.'
    );
}
