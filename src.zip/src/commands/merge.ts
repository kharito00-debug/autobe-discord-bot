import {
    ChatInputCommandInteraction,
    SlashCommandBuilder,
    AttachmentBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuInteraction,
    EmbedBuilder
} from 'discord.js';
import JSZip from 'jszip';
import { v4 as uuidv4 } from 'uuid';
import { PackReader } from '../core/PackReader';
import { ConflictDetector } from '../core/ConflictDetector';
import { Merger } from '../core/Merger';
import { ProcessedPack, MergeConfig, Conflict } from '../core/types';
import { downloadFile, uploadToHost } from '../utils/fileHost';

export const data = new SlashCommandBuilder()
    .setName('merge')
    .setDescription('Merge multiple Minecraft Addon packs.')
    .addAttachmentOption(option =>
        option.setName('file')
            .setDescription('Upload a .zip or .mcaddon file containing your packs')
            .setRequired(false))
    .addStringOption(option =>
        option.setName('url')
            .setDescription('Link to a hosted .zip or .mcaddon file (for large files)')
            .setRequired(false))
    .addBooleanOption(option =>
        option.setName('log')
            .setDescription('Include a merge log file in the output')
            .setRequired(false));

export async function execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();

    const attachment = interaction.options.getAttachment('file');
    const url = interaction.options.getString('url');
    const generateLog = interaction.options.getBoolean('log') ?? false;

    if (!attachment && !url) {
        return interaction.editReply('You must provide either a file attachment or a URL.');
    }

    try {
        const downloadUrl = attachment ? attachment.url : url!;
        await interaction.editReply('📥 Downloading packs...');
        const buffer = await downloadFile(downloadUrl);

        await interaction.editReply('📦 Extracting and analyzing packs...');
        const mainZip = await JSZip.loadAsync(buffer);
        const packs: ProcessedPack[] = [];

        for (const [path, file] of Object.entries(mainZip.files)) {
            if (!file.dir && (path.endsWith('.mcpack') || path.endsWith('.zip'))) {
                const packBuffer = await file.async('nodebuffer');
                const pack = await PackReader.read(packBuffer, path);
                packs.push(pack);
            }
        }

        if (packs.length === 0) {
            return interaction.editReply('No valid .mcpack files found inside the provided file.');
        }

        ConflictDetector.resolveLinks(packs);

        // ── Pre-flight warnings ────────────────────────────────────────────
        const obfuscatedPacks = packs.filter(p => p.obfuscated);
        const achievementPacks = packs.filter(p => p.disablesAchievements);

        let preflight = '';
        if (obfuscatedPacks.length > 0) {
            preflight += `⚠️ **${obfuscatedPacks.length} pack(s) appear obfuscated** (may not merge cleanly):\n`;
            preflight += obfuscatedPacks.map(p => `  • ${p.name}`).join('\n') + '\n\n';
        }
        if (achievementPacks.length > 0) {
            preflight += `🏆 **${achievementPacks.length} pack(s) will disable achievements**:\n`;
            preflight += achievementPacks.map(p => `  • ${p.name} (${(p.manifest.capabilities ?? []).join(', ')})`).join('\n') + '\n\n';
        }
        if (preflight) {
            await interaction.editReply({ content: `${preflight}Continuing with merge...` });
        }

        // ── Subpack selection UI ───────────────────────────────────────────
        const packsWithSubpacks = packs.filter(p => p.manifest.subpacks && p.manifest.subpacks.length > 0);
        const subpackSelections: Record<string, string> = {};
        packsWithSubpacks.forEach(p => {
            subpackSelections[p.id] = p.manifest.subpacks![0].folder_name;
        });

        if (packsWithSubpacks.length > 0) {
            const PAGE_SIZE = 4;
            const totalPages = Math.ceil(packsWithSubpacks.length / PAGE_SIZE);
            let currentPage = 0;

            const buildPageComponents = (page: number) => {
                const components: any[] = [];
                const pagePacks = packsWithSubpacks.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
                pagePacks.forEach(pack => {
                    const selectMenu = new StringSelectMenuBuilder()
                        .setCustomId(`subpack_${pack.id}`)
                        .setPlaceholder(`Select subpack for ${pack.name}`)
                        .addOptions(pack.manifest.subpacks!.map(s => ({
                            label: s.name,
                            description: `Folder: ${s.folder_name}`,
                            value: s.folder_name
                        })));
                    components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu));
                });
                const isLastPage = page === totalPages - 1;
                const navBtn = isLastPage
                    ? new ButtonBuilder().setCustomId('confirm_merge').setLabel('Confirm & Merge').setStyle(ButtonStyle.Success)
                    : new ButtonBuilder().setCustomId('next_page').setLabel(`Next (${page + 1}/${totalPages}) →`).setStyle(ButtonStyle.Primary);
                components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(navBtn));
                return components;
            };

            const buildPageContent = (page: number) => {
                const start = page * PAGE_SIZE + 1;
                const end = Math.min((page + 1) * PAGE_SIZE, packsWithSubpacks.length);
                return `⚙️ **Subpacks Detected!** Configure addons **${start}–${end}** of **${packsWithSubpacks.length}** below.`;
            };

            const msg = await interaction.editReply({ content: buildPageContent(0), components: buildPageComponents(0) });
            const collector = msg.createMessageComponentCollector({
                filter: i => i.user.id === interaction.user.id,
                time: 300_000
            });

            collector.on('collect', async i => {
                if (i.customId.startsWith('subpack_')) {
                    subpackSelections[i.customId.replace('subpack_', '')] = (i as StringSelectMenuInteraction).values[0];
                    await i.deferUpdate();
                } else if (i.customId === 'next_page') {
                    currentPage++;
                    await i.update({ content: buildPageContent(currentPage), components: buildPageComponents(currentPage) });
                } else if (i.customId === 'confirm_merge') {
                    await i.update({ content: '⏳ Starting merge process...', components: [] });
                    collector.stop('merged');
                }
            });

            collector.on('end', async (_, reason) => {
                if (reason === 'merged') {
                    await performMerge(interaction, packs, subpackSelections, generateLog);
                } else {
                    await interaction.editReply({ content: '⏰ Merge timed out.', components: [] });
                }
            });
        } else {
            await performMerge(interaction, packs, subpackSelections, generateLog);
        }

    } catch (err: any) {
        console.error(err);
        await interaction.editReply(`❌ An error occurred: ${err.message}`);
    }
}

// ── Auto-resolve conflicts ────────────────────────────────────────────────────
function autoResolveConflicts(conflicts: Conflict[]): void {
    conflicts.forEach(c => {
        // Obfuscated and achievement conflicts are informational only — mark resolved but don't change behaviour
        if (c.type === 'obfuscated' || c.type === 'achievement' || c.type === 'version' || c.type === 'dependency') {
            c.resolved = true;
            c.resolution = { type: 'manual' }; // No structural change needed
            return;
        }
        c.resolved = true;
        c.resolution = {
            type: c.type.startsWith('file') && !c.idsOverlap ? 'keep_both' : 'keep_one',
            selectedPackId: c.sources[0].packId
        };
    });
}

// ── Send result to Discord or file host ───────────────────────────────────────
async function sendResult(interaction: ChatInputCommandInteraction, buffer: Buffer, filename: string): Promise<void> {
    if (buffer.length > 20 * 1024 * 1024) {
        await interaction.editReply('🌐 File is large — uploading to temporary host...');
        const link = await uploadToHost(buffer, filename);
        await interaction.editReply(
            `✅ Merge complete! File was too large for Discord.\n📥 **Download here:** ${link}\n*(Temporary link — download soon, it will expire)*`
        );
    } else {
        const att = new AttachmentBuilder(buffer, { name: filename });
        await interaction.editReply({ content: '✅ Merge complete! Download your addon below:', files: [att] });
    }
}

// ── Core merge function ───────────────────────────────────────────────────────
async function performMerge(
    interaction: ChatInputCommandInteraction,
    packs: ProcessedPack[],
    subpackSelections: Record<string, string>,
    generateLog: boolean
) {
    await interaction.editReply('🔍 Analyzing conflicts...');
    const conflicts = await ConflictDetector.detect(packs);
    autoResolveConflicts(conflicts);

    // Summarise conflicts to user
    const warnConflicts = conflicts.filter(c =>
        c.type !== 'obfuscated' && c.type !== 'achievement' && c.resolved
    );
    if (warnConflicts.length > 0) {
        const summary = warnConflicts.slice(0, 5).map(c => `• \`${c.pathOrId.substring(0, 80)}\``).join('\n');
        const more = warnConflicts.length > 5 ? `\n…and ${warnConflicts.length - 5} more` : '';
        await interaction.editReply(`🔍 Found ${warnConflicts.length} conflict(s) — auto-resolving:\n${summary}${more}\n\n🚀 Merging…`);
    } else {
        await interaction.editReply('🚀 Merging packs (this might take a moment)...');
    }

    const baseConfig: MergeConfig = {
        outputName: 'Merged Addon',
        outputDescription: 'Merged via Discord Bot',
        version: [1, 0, 0],
        generateLog,
        separatePacks: false,
        makeCompatible: true,
        subpackSelections
    };

    try {
        const groups = ConflictDetector.groupPacksForCompatibility(packs);
        const universalPacks = [...groups.universalGroup.rps, ...groups.universalGroup.scriptlessBps];
        const scriptVersionKeys = Object.keys(groups.scriptGroups).sort();

        if (scriptVersionKeys.length === 0) {
            if (universalPacks.length === 0) {
                await interaction.editReply('❌ No compatible packs found to merge.');
                return;
            }
            const { buffer, logs } = await Merger.merge(universalPacks, conflicts, baseConfig);
            if (generateLog && logs.length > 0) {
                const warns = logs.filter(l => l.level !== 'info').length;
                if (warns > 0) await interaction.followUp({ content: `⚠️ ${warns} warning(s) in merge log (included in output).`, ephemeral: true }).catch(() => {});
            }
            await sendResult(interaction, buffer, 'Merged_Addon.mcaddon');
            return;
        }

        // Multi-version scripted bundle
        await interaction.editReply('🔧 Building compatible multi-version bundle...');
        const sharedRpUuid = uuidv4();
        const finalBundleZip = new JSZip();
        const primaryVersion = scriptVersionKeys[0];

        const primaryPacks = [...universalPacks, ...groups.scriptGroups[primaryVersion]];
        const primaryConfig: MergeConfig = { ...baseConfig, fixedRpUuid: sharedRpUuid, outputName: `${baseConfig.outputName} ${primaryVersion}` };
        const { buffer: primaryBuffer, logs: primaryLogs } = await Merger.merge(primaryPacks, conflicts, primaryConfig);
        const primaryZip = await JSZip.loadAsync(primaryBuffer);

        const primaryRp = await primaryZip.file('ResourcePack.mcpack')?.async('nodebuffer');
        const primaryBp = await primaryZip.file('BehaviorPack.mcpack')?.async('nodebuffer');
        if (primaryRp) finalBundleZip.file('ResourcePack.mcpack', primaryRp);
        if (primaryBp) finalBundleZip.file(`BehaviorPack_${primaryVersion.replace(/\./g, '_')}.mcpack`, primaryBp);

        for (const version of scriptVersionKeys) {
            if (version === primaryVersion) continue;
            const secConfig: MergeConfig = { ...baseConfig, fixedRpUuid: sharedRpUuid, outputName: `${baseConfig.outputName} ${version}` };
            const { buffer: secBuffer } = await Merger.merge(groups.scriptGroups[version], conflicts, secConfig);
            const secZip = await JSZip.loadAsync(secBuffer);
            const secBp = await secZip.file('BehaviorPack.mcpack')?.async('nodebuffer');
            if (secBp) finalBundleZip.file(`BehaviorPack_${version.replace(/\./g, '_')}.mcpack`, secBp);
        }

        const bundleBuffer = await finalBundleZip.generateAsync({ type: 'nodebuffer' });
        await sendResult(interaction, bundleBuffer, 'Merged_Addon_Bundle.mcaddon');

    } catch (err: any) {
        console.error(err);
        await interaction.editReply(`❌ Merge failed: ${err.message}`);
    }
}
