import { jsonrepair } from 'jsonrepair';

export class JsonHandler {
    /**
     * Sanitizes raw JSON text for common MCBE issues before structural repair.
     * Implements "Intelligent Uncommenting" and handles control characters.
     */
    static sanitize(text: string): string {
        if (!text) return '';

        // 1. Remove UTF-8 BOM if present
        let clean = text.replace(/^\uFEFF/, '');

        // 2. Intelligent Uncommenting (Improved)
        // We look for lines starting with // or / that contain valid JSON-like structures.
        // We must preserve the WHOLE line to avoid the data loss reported by the user.

        // Uncomment property lines: // "key": value...
        clean = clean.replace(/^[ \t]*\/\/?\s*("[^"]+"\s*:.*)$/gm, '$1');

        // Uncomment structural lines: // { or // [ or // } or // ] or // ,
        clean = clean.replace(/^[ \t]*\/\/?\s*([\{\[\]\},].*)$/gm, '$1');

        // 3. Handle "Bad control character in string literal"
        // This regex finds double-quoted strings and handles escaped quotes (\") correctly.
        // Within these strings, we escape literal newlines, carriage returns, and tabs.
        // This is done BEFORE jsonrepair to ensure it sees valid string tokens.
        clean = clean.replace(/"((?:[^"\\]|\\.)*)"/g, (_, p1) => {
            return '"' + p1.replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
        });

        // 4. Escape remaining illegal non-whitespace ASCII control characters (0-31)
        // This prevents JSON.parse from failing on unescaped symbols.
        clean = clean.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, (match) => {
            return '\\u' + match.charCodeAt(0).toString(16).padStart(4, '0');
        });

        return clean.trim();
    }

    /**
     * Repairs and returns a JSON string, handling comments and common syntax errors.
     */
    static repair(text: string): string {
        // Step 1: Sanitize (BOM, Smart Uncommenting, Control Character Escaping)
        const sanitized = this.sanitize(text);

        try {
            // Step 2: Structural repair using jsonrepair.
            // jsonrepair natively handles remaining comments (stripping them safely)
            // and fixes missing commas, brackets, and quotes.
            return jsonrepair(sanitized);
        } catch (e) {
            console.warn('jsonrepair failed. Attempting aggressive comment stripping as last resort.', e);

            // Aggressive fallback: strip all remaining comments and try again
            try {
                const noComments = sanitized
                    .replace(/\/\/.*$/gm, '')
                    .replace(/\/\*[\s\S]*?\*\//g, '');
                return jsonrepair(noComments);
            } catch (inner) {
                // If even the fallback fails, return the best we have (sanitized)
                return sanitized;
            }
        }
    }

    /**
     * Safely parses JSON with repair logic.
     */
    static parse<T = any>(text: string): T {
        if (!text) return {} as T;

        const repaired = this.repair(text);
        try {
            return JSON.parse(repaired);
        } catch (e) {
            console.error('Final JSON parse failed. Analysis of problem file:', (e as any).message);
            // We throw here so the caller (PackReader/Merger) can report the failure relative to the file path.
            throw e;
        }
    }

    /**
     * Like parse(), but returns null instead of throwing on failure.
     * Use this when a failed parse should be a soft skip, not a crash.
     */
    static tryParse<T = any>(text: string): T | null {
        try {
            return this.parse<T>(text);
        } catch {
            return null;
        }
    }
}
