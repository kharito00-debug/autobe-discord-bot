import JSZip from 'jszip';
import { v4 as uuidv4 } from 'uuid';
import { JsonHandler } from './JsonHandler';
import { TextUtility } from './TextUtility';
import type { PackManifest, ProcessedPack, PackType } from './types';

/** Capabilities that disable achievements in Minecraft Bedrock. */
const ACHIEVEMENT_DISABLING_CAPS = new Set([
    'experimental_custom_ui',
    'script_eval',
    'chemistry',
    'editorExtension',
    'pbr'
]);

export class PackReader {
    static async read(buffer: Buffer, fileName: string): Promise<ProcessedPack> {
        const zip = new JSZip();
        try {
            const content = await zip.loadAsync(buffer);
            let manifestFile = content.file('manifest.json');

            if (!manifestFile) {
                const allFiles = Object.keys(content.files);
                const manifestPath = allFiles.find(p =>
                    p.toLowerCase().endsWith('manifest.json') && p.split('/').length <= 2
                );
                if (manifestPath) manifestFile = content.file(manifestPath);
            }

            if (!manifestFile) throw new Error('manifest.json not found in the pack');

            const manifestContent = await manifestFile.async('string');
            const manifest: PackManifest = JsonHandler.parse(manifestContent);

            const types: PackType[] = [];
            manifest.modules.forEach(m => {
                if (m.type === 'resources') types.push('resource');
                if (m.type === 'data') types.push('behavior');
                if (m.type === 'script') types.push('script');
            });

            // Icon
            let iconBase64: string | undefined = undefined;
            const iconPath = Object.keys(content.files).find(p => p.toLowerCase() === 'pack_icon.png');
            if (iconPath) {
                const iconData = await content.file(iconPath)?.async('base64');
                if (iconData) iconBase64 = iconData;
            }

            // Obfuscation detection (AutoBE: */ prefix OR high Unicode-escape density)
            let obfuscated = false;
            for (const [path, zipObj] of Object.entries(content.files)) {
                if (zipObj.dir) continue;
                const lp = path.toLowerCase();
                if (lp.endsWith('.png') || lp.endsWith('.tga') || lp.endsWith('.ogg') ||
                    lp.endsWith('.fsb') || lp.endsWith('.wav')) continue;

                const raw = await zipObj.async('uint8array');
                const text = new TextDecoder('utf-8', { fatal: false }).decode(raw);

                // AutoBE marker 1: starts with '*/' — illegal JSON used as protection
                const trimmed = text.trimStart();
                if (trimmed.startsWith('*/')) {
                    obfuscated = true;
                    break;
                }
                // AutoBE marker 2: high Unicode escape density
                if (TextUtility.isObfuscated(text)) {
                    obfuscated = true;
                    break;
                }
            }

            // Achievement compatibility detection
            const caps: string[] = manifest.capabilities ?? [];
            const disablesAchievements = caps.some(c => ACHIEVEMENT_DISABLING_CAPS.has(c));

            return {
                id: uuidv4(),
                fileName,
                name: manifest.header.name,
                type: [...new Set(types)],
                manifest,
                files: new Map(Object.entries(content.files)),
                icon: iconBase64,
                obfuscated,
                disablesAchievements
            };
        } catch (e) {
            throw new Error(`Failed to read pack ${fileName}: ${e instanceof Error ? e.message : 'Unknown error'}`);
        }
    }
}
