import { VERSION_KEYS, FIRST_WINS_DICT_KEYS, CONCATENATE_ARRAY_KEYS, MergeLogEntry } from './types';

/**
 * Universal JSON merger ported from AutoBE.py's UniversalJsonMerger.
 * Applies context-aware merge strategies:
 * - format_version / min_engine_version: keep highest
 * - animations, render_controllers, etc.: first-wins per entry ID with compat check
 * - initialize / pre_animation arrays: concatenate with variable-redefinition detection
 * - variables dicts: merge with conflict warnings
 * - Everything else: recursive deep merge
 */
export class UniversalJsonMerger {
    conflicts: string[] = [];
    warnings: string[] = [];

    /** Merge an ordered list of JSON objects into one, returning the result. */
    mergeJsonList(jsonList: any[], filePath?: string): any {
        if (!jsonList || jsonList.length === 0) return {};
        this.conflicts = [];
        this.warnings = [];

        const fileType = this._detectFileType(jsonList[0], filePath);
        let merged = this._deepClone(jsonList[0]);

        for (let i = 1; i < jsonList.length; i++) {
            try {
                merged = this._mergeObjects(merged, jsonList[i], fileType, '');
            } catch (e: any) {
                this.warnings.push(`Smart merge failed for ${filePath ?? 'unknown'}, using fallback: ${e?.message ?? e}`);
                merged = this._fallbackMerge(merged, jsonList[i]);
            }
        }
        return merged;
    }

    private _detectFileType(jsonObj: any, filePath?: string): string {
        if (filePath) {
            const fp = filePath.toLowerCase();
            if ((fp.includes('entity') || fp.includes('entities')) && fp.endsWith('.json')) {
                if (fp.includes('client_entity') || 'minecraft:client_entity' in (jsonObj ?? {})) return 'client_entity';
                if ('minecraft:entity' in (jsonObj ?? {})) return 'entity';
            }
            if (fp.includes('item')) return 'item';
            if (fp.includes('block')) return 'block';
        }
        if (jsonObj && typeof jsonObj === 'object') {
            if ('minecraft:client_entity' in jsonObj) return 'client_entity';
            if ('minecraft:entity' in jsonObj) return 'entity';
            if ('minecraft:item' in jsonObj) return 'item';
            if ('minecraft:block' in jsonObj) return 'block';
        }
        return 'generic';
    }

    private _mergeObjects(base: any, overlay: any, fileType: string, path: string): any {
        if (overlay === null || overlay === undefined) return base;
        if (typeof base !== 'object' || typeof overlay !== 'object') {
            // Primitive: last-wins unless it's a version key
            return overlay;
        }
        if (Array.isArray(base) && Array.isArray(overlay)) {
            return this._mergeLists(base, overlay, path);
        }
        if (Array.isArray(base) !== Array.isArray(overlay)) {
            return overlay;
        }

        const result = { ...base };
        for (const [key, value] of Object.entries(overlay)) {
            const currentPath = path ? `${path}.${key}` : key;

            if (!(key in result)) {
                result[key] = value;
                continue;
            }

            const baseVal = result[key];

            // Version keys: keep highest
            if (VERSION_KEYS.has(key)) {
                result[key] = this._compareVersions(baseVal, value);
                continue;
            }

            if (typeof baseVal === 'object' && !Array.isArray(baseVal) &&
                typeof value === 'object' && !Array.isArray(value) &&
                baseVal !== null && value !== null) {

                if (FIRST_WINS_DICT_KEYS.has(key)) {
                    // First-wins per entry ID with compatibility check
                    const merged = { ...baseVal };
                    for (const [entryId, entryData] of Object.entries(value as Record<string, any>)) {
                        if (!(entryId in merged)) {
                            merged[entryId] = entryData;
                        } else if (this._areEntriesCompatible(merged[entryId], entryData, key)) {
                            merged[entryId] = this._mergeObjects(merged[entryId], entryData, fileType, currentPath);
                        } else {
                            this.conflicts.push(`Incompatible ${key} entry '${entryId}' at ${currentPath}`);
                        }
                    }
                    result[key] = merged;
                } else if (key === 'variables') {
                    result[key] = this._mergeVariables(baseVal, value as Record<string, any>, currentPath);
                } else if (key === 'description') {
                    // Merge descriptions dict recursively
                    result[key] = this._mergeObjects(baseVal, value, fileType, currentPath);
                } else {
                    result[key] = this._mergeObjects(baseVal, value, fileType, currentPath);
                }
            } else if (Array.isArray(baseVal) && Array.isArray(value)) {
                result[key] = this._mergeLists(baseVal, value, currentPath);
            } else {
                // Primitive last-wins (but version keys already handled above)
                result[key] = value;
            }
        }
        return result;
    }

    private _mergeLists(base: any[], overlay: any[], path: string): any[] {
        const lowerPath = path.toLowerCase();
        const lastKey = path.split('.').pop() ?? '';

        const isConcatKey = CONCATENATE_ARRAY_KEYS.has(lastKey) || lowerPath.includes('scripts');
        const isInitialize = lastKey === 'initialize' || lowerPath.includes('initialize');

        if (isInitialize) {
            return this._concatenateWithVariableCheck(base, overlay, path);
        }
        if (isConcatKey) {
            return this._concatenateUnique(base, overlay);
        }
        // Default: last-wins (overlay replaces base)
        return overlay;
    }

    private _areEntriesCompatible(entry1: any, entry2: any, keyType: string): boolean {
        if (typeof entry1 !== typeof entry2) return false;
        if (typeof entry1 !== 'object' || entry1 === null || entry2 === null) return true;

        const keys1 = new Set(Object.keys(entry1));
        const keys2 = new Set(Object.keys(entry2));

        // Large structural differences => incompatible
        if (Math.abs(keys1.size - keys2.size) > 3) return false;

        // Check critical keys that would break behaviour if different
        const criticalKeys = ['loops', 'blend_expression', 'anim_time_update', 'transition_duration'];
        for (const ck of criticalKeys) {
            if (ck in entry1 && ck in entry2 && entry1[ck] !== entry2[ck]) return false;
        }
        return true;
    }

    private _mergeVariables(baseVars: Record<string, any>, overlayVars: Record<string, any>, path: string): Record<string, any> {
        const result = { ...baseVars };
        for (const [varName, varValue] of Object.entries(overlayVars)) {
            if (!(varName in result)) {
                result[varName] = varValue;
            } else if (JSON.stringify(result[varName]) !== JSON.stringify(varValue)) {
                this.warnings.push(`Variable '${varName}' redefined with different value at ${path}`);
                result[varName] = varValue; // last-wins
            }
        }
        return result;
    }

    private _concatenateWithVariableCheck(base: any[], overlay: any[], path: string): any[] {
        const baseVars = this._extractVariables(base);
        const overlayVars = this._extractVariables(overlay);

        for (const [varName, val] of Object.entries(overlayVars)) {
            if (varName in baseVars && baseVars[varName] !== val) {
                this.warnings.push(`Variable '${varName}' redefined in scripts at ${path}`);
            }
        }
        return this._concatenateUnique(base, overlay);
    }

    private _extractVariables(scriptList: any[]): Record<string, string> {
        const vars: Record<string, string> = {};
        for (const item of scriptList) {
            if (typeof item === 'string') {
                const m = item.match(/(?:variable|v)\.(\w+)\s*=\s*(.+)/);
                if (m) {
                    vars[m[1]] = m[2].trim();
                }
            }
        }
        return vars;
    }

    private _concatenateUnique(base: any[], overlay: any[]): any[] {
        const existing = new Set(base.map(i => JSON.stringify(i)));
        const result = [...base];
        for (const item of overlay) {
            const key = JSON.stringify(item);
            if (!existing.has(key)) {
                result.push(item);
                existing.add(key);
            }
        }
        return result;
    }

    /** Keep the highest of two version values (list or string). */
    _compareVersions(v1: any, v2: any): any {
        try {
            const toArr = (v: any): number[] => {
                if (Array.isArray(v)) return v.map(Number);
                if (typeof v === 'string') return v.split('.').map(p => parseInt(p, 10) || 0);
                return [0];
            };
            const a = toArr(v1);
            const b = toArr(v2);
            const len = Math.max(a.length, b.length);
            for (let i = 0; i < len; i++) {
                if ((a[i] ?? 0) > (b[i] ?? 0)) return v1;
                if ((b[i] ?? 0) > (a[i] ?? 0)) return v2;
            }
            return v1; // equal, keep first
        } catch {
            return v2; // fallback last-wins
        }
    }

    private _fallbackMerge(base: any, overlay: any): any {
        if (typeof base !== 'object' || typeof overlay !== 'object') return overlay;
        if (Array.isArray(base) && Array.isArray(overlay)) return [...base, ...overlay];
        const result = { ...base };
        for (const [key, value] of Object.entries(overlay ?? {})) {
            if (!(key in result)) {
                result[key] = value;
            } else if (typeof result[key] === 'object' && typeof value === 'object') {
                result[key] = this._fallbackMerge(result[key], value);
            } else {
                result[key] = value;
            }
        }
        return result;
    }

    private _deepClone(obj: any): any {
        return JSON.parse(JSON.stringify(obj));
    }

    /** Collect all log entries as MergeLogEntry[]. */
    getLogs(): MergeLogEntry[] {
        const entries: MergeLogEntry[] = [];
        for (const c of this.conflicts) entries.push({ level: 'warning', message: `Conflict: ${c}` });
        for (const w of this.warnings) entries.push({ level: 'warning', message: `Warning: ${w}` });
        return entries;
    }
}
