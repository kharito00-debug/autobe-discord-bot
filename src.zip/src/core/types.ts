import JSZip from 'jszip';

export type PackType = 'resource' | 'behavior' | 'skin' | 'world_template' | 'script' | 'unknown';

export interface PackHeader {
    name: string;
    description: string;
    uuid: string;
    version: [number, number, number];
    min_engine_version?: [number, number, number];
}

export interface PackModule {
    type: string;
    uuid: string;
    version: [number, number, number];
    description?: string;
    language?: string;
    entry?: string;
}

export interface PackManifest {
    format_version: number;
    header: PackHeader;
    modules: PackModule[];
    dependencies?: any[];
    capabilities?: string[];
    metadata?: {
        authors?: string[];
        license?: string;
        url?: string;
        generated_with?: string;
    };
    subpacks?: SubpackDefinition[];
}

export interface SubpackDefinition {
    folder_name: string;
    name: string;
    memory_tier: number;
}

export interface ProcessedPack {
    id: string;
    fileName: string;
    name: string;
    type: PackType[];
    manifest: PackManifest;
    files: Map<string, JSZip.JSZipObject>;
    icon?: string;
    obfuscated?: boolean;
    linkedPackId?: string;
    /** True if the pack disables achievements (has 'experimental_custom_ui' or similar capabilities) */
    disablesAchievements?: boolean;
}

export interface MergeConfig {
    outputName: string;
    outputDescription: string;
    version: [number, number, number];
    generateLog: boolean;
    separatePacks: boolean;
    subpackSelections?: Record<string, string>;
    makeCompatible: boolean;
    fixedRpUuid?: string;
}

export type ConflictType =
    | 'file_binary'
    | 'file_content'
    | 'identifier'
    | 'subpack'
    | 'version'
    | 'dependency'
    | 'ui_def'
    | 'obfuscated'
    | 'achievement'
    | 'script_variable';

export interface Conflict {
    id: string;
    type: ConflictType;
    pathOrId: string;
    category?: 'BP' | 'RP';
    sources: {
        packId: string;
        packName: string;
        value?: any;
        ids?: string[];
    }[];
    resolved?: boolean;
    resolution?: ResolutionStrategy;
    idsOverlap?: boolean;
}

export interface ResolutionStrategy {
    type: 'keep_one' | 'keep_both' | 'rename' | 'merge_json' | 'manual';
    selectedPackId?: string;
    renameMap?: Record<string, string>;
}

export interface MergeLogEntry {
    level: 'info' | 'warning' | 'error';
    message: string;
    file?: string;
    packName?: string;
}

export interface IdentifierConflictResolution {
    /** identifier -> packId to keep (undefined = keep all / deep-merge) */
    [identifier: string]: string | undefined;
}

export const MERGE_TARGETS: string[] = [
    "functions/tick.json", "blocks.json", "sounds.json", "splashes.json", "sounds/sound_definitions.json",
    "texts/languages.json", "textures/item_texture.json", "textures/terrain_texture.json",
    "ui/_ui_defs.json", "ui/hud_screen.json", "ui/server_form.json", "ui/horse_screen.json",
    "textures/flipbook_textures.json", "sounds/music_definitions.json",
    "ui/npc_interact_screen.json", "ui/_global_variables.json", "ui/ui_common.json",
    "biomes_client.json"
];

/** Keys whose values should be compared as version strings/arrays (keep highest). */
export const VERSION_KEYS = new Set(['format_version', 'min_engine_version']);

/** Keys where each child entry should be merged by ID (first-wins per entry, with compatibility check). */
export const FIRST_WINS_DICT_KEYS = new Set([
    'animations', 'animation_controllers', 'render_controllers',
    'materials', 'textures', 'sounds', 'particle_effects'
]);

/** Keys whose array values should be concatenated (deduped). */
export const CONCATENATE_ARRAY_KEYS = new Set([
    'initialize', 'pre_animation', 'animate', 'scripts'
]);
