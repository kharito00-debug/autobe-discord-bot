import JSZip from 'jszip';
import { v4 as uuidv4 } from 'uuid';
import { JsonHandler } from './JsonHandler';
import { TextUtility } from './TextUtility';
import { ConflictDetector } from './ConflictDetector';
import { UniversalJsonMerger } from './UniversalJsonMerger';
import { IdentifierManager } from './IdentifierManager';
import type { ProcessedPack, Conflict, MergeConfig, MergeLogEntry } from './types';
import { MERGE_TARGETS, VERSION_KEYS } from './types';

export class Merger {
    static async merge(
        packs: ProcessedPack[],
        conflicts: Conflict[],
        config: MergeConfig
    ): Promise<{ buffer: Buffer; logs: MergeLogEntry[] }> {
        const logs: MergeLogEntry[] = [];
        const log = (level: MergeLogEntry['level'], message: string, file?: string, packName?: string) => {
            logs.push({ level, message, file, packName });
        };

        const rpZip = new JSZip();
        const bpZip = new JSZip();

        const rpFiles: Map<string, ArrayBuffer | string> = new Map();
        const bpFiles: Map<string, ArrayBuffer | string> = new Map();

        // Deep-merge stores: path -> parsed JSON list (merged progressively)
        const rpDeepMerge: Record<string, any> = {};
        const bpDeepMerge: Record<string, any> = {};

        // Script handling
        const scriptImports: string[] = [];
        const bpDependencies: Record<string, [number, number, number] | string> = {};
        let maxEngineVersion: [number, number, number] = [0, 0, 0];

        // IdentifierManager for cross-pack identifier resolution
        const idManager = new IdentifierManager();
        for (const pack of packs) await idManager.scanPack(pack);
        await idManager.detectConflicts(packs);
        idManager.generateMappings();

        // UniversalJsonMerger for smart JSON merging
        const jsonMerger = new UniversalJsonMerger();

        // ── Helper: version normalise ──────────────────────────────────────
        const normalizeVersion = (v: any): [number, number, number] => {
            if (Array.isArray(v)) return [Number(v[0]) || 0, Number(v[1]) || 0, Number(v[2]) || 0];
            if (typeof v === 'string') {
                const parts = v.split('.').map(p => parseInt(p, 10) || 0);
                return [parts[0] || 0, parts[1] || 0, parts[2] || 0];
            }
            return [0, 0, 0];
        };
        const versionGt = (v1: number[], v2: number[]) => {
            for (let i = 0; i < 3; i++) {
                if ((v1[i] ?? 0) > (v2[i] ?? 0)) return true;
                if ((v1[i] ?? 0) < (v2[i] ?? 0)) return false;
            }
            return false;
        };

        // ── 1. Process each pack ───────────────────────────────────────────
        for (const pack of packs) {
            const isBp = pack.manifest.modules.some((m: any) => m.type === 'data' || m.type === 'script');
            const isRp = pack.manifest.modules.some((m: any) => m.type === 'resources');

            // Update max engine version
            const evRaw = pack.manifest.header.min_engine_version;
            if (evRaw) {
                const ev = normalizeVersion(evRaw);
                if (versionGt(ev, maxEngineVersion)) maxEngineVersion = ev;
            }

            // Collect dependencies (highest version wins)
            if (pack.manifest.dependencies) {
                for (const dep of pack.manifest.dependencies) {
                    if (dep.module_name && dep.module_name.startsWith('@minecraft/')) {
                        const currentVer = dep.version;
                        const existingVer = bpDependencies[dep.module_name];
                        if (!existingVer) {
                            bpDependencies[dep.module_name] = currentVer;
                        } else {
                            const verA = normalizeVersion(existingVer);
                            const verB = normalizeVersion(currentVer);
                            const isSpecialA = typeof existingVer === 'string' && verA.every((v: number) => v === 0) && existingVer !== '0.0.0';
                            const isSpecialB = typeof currentVer === 'string' && verB.every((v: number) => v === 0) && currentVer !== '0.0.0';
                            if (isSpecialB && !isSpecialA) bpDependencies[dep.module_name] = currentVer;
                            else if (!isSpecialB && versionGt(verB, verA)) bpDependencies[dep.module_name] = currentVer;
                        }
                    }
                }
            }

            const scriptEntry = pack.manifest.modules.find((m: any) => m.type === 'script')?.entry || 'scripts/main.js';
            const packShortId = pack.id.substring(0, 8);

            // ── Subpack pre-processing ──────────────────────────────────────
            const effectiveFiles = new Map<string, JSZip.JSZipObject>();
            const selectedSubpack = config.subpackSelections?.[pack.id] || pack.manifest.subpacks?.[0]?.folder_name;

            for (const [path, zipObj] of pack.files) {
                if (path.toLowerCase().startsWith('subpacks/')) continue;
                effectiveFiles.set(path, zipObj);
            }
            if (selectedSubpack) {
                const prefix = `subpacks/${selectedSubpack}/`;
                for (const [path, zipObj] of pack.files) {
                    if (path.toLowerCase().startsWith(prefix.toLowerCase())) {
                        const rootPath = path.substring(prefix.length);
                        if (rootPath) effectiveFiles.set(rootPath, zipObj);
                    }
                }
            }

            const renamedScripts = new Map<string, string>();
            let entryFileContent: string | undefined;
            let entryFilePath: string | undefined;

            // ── Process each file ───────────────────────────────────────────
            for (let [path, zipObj] of effectiveFiles) {
                let lowerPath = path.toLowerCase();

                if (['manifest.json', 'pack_icon.json', 'pack_icon.png'].includes(lowerPath)) continue;
                if (path.endsWith('/')) continue;

                // Determine target type
                let targetType: 'RP' | 'BP' = 'BP';
                if (isRp && !isBp) targetType = 'RP';
                else if (!isRp && isBp) targetType = 'BP';
                else {
                    if (lowerPath.startsWith('textures/') || lowerPath.startsWith('ui/') || lowerPath.startsWith('models/') ||
                        lowerPath.startsWith('particles/') || lowerPath.startsWith('fogs/') || lowerPath.startsWith('font/') ||
                        lowerPath.startsWith('materials/')) {
                        targetType = 'RP';
                    } else {
                        targetType = 'BP';
                    }
                    if (lowerPath.startsWith('texts/') && !lowerPath.includes('en_us.lang')) targetType = 'RP';
                }

                const content = await zipObj.async('uint8array');
                let text: string | undefined;

                // ── Script files ────────────────────────────────────────────
                if (targetType === 'BP' && lowerPath.startsWith('scripts/')) {
                    text = TextUtility.decodeUnicode(new TextDecoder().decode(content));
                    const normalizedEntry = scriptEntry.replace(/\\/g, '/');
                    const normalizedCurrent = path.replace(/\\/g, '/');

                    if (normalizedCurrent === normalizedEntry) {
                        entryFileContent = text;
                        entryFilePath = path;
                    } else {
                        if (bpFiles.has(path)) {
                            const existing = bpFiles.get(path);
                            if (existing !== text) {
                                const ext = path.includes('.') ? path.split('.').pop() : 'js';
                                const dir = path.includes('/') ? path.substring(0, path.lastIndexOf('/') + 1) : 'scripts/';
                                const name = path.substring(dir.length, path.length - (ext ? ext.length + 1 : 0));
                                const renamedPath = `${dir}${name}_${packShortId}.${ext}`;
                                bpFiles.set(renamedPath, text);
                                renamedScripts.set(path, renamedPath);
                                log('info', `Script renamed to avoid collision: ${renamedPath}`, path, pack.name);
                            }
                        } else {
                            bpFiles.set(path, text);
                        }
                    }
                    continue;
                }

                // ── JSON files ──────────────────────────────────────────────
                if (lowerPath.endsWith('.json') || MERGE_TARGETS.some(t => t.toLowerCase() === lowerPath)) {
                    try {
                        text = TextUtility.decodeUnicode(new TextDecoder().decode(content));
                    } catch { /* binary, skip */ }
                }

                if (text !== undefined && lowerPath.endsWith('.json')) {
                    try {
                        const ids = ConflictDetector.extractIdentifiers(text, path);

                        // Player entity: always deep-merge
                        const isPlayerFile = ids.some(id => id === 'minecraft:player') ||
                            lowerPath.includes('entities/player.json') || lowerPath.includes('entity/player.json');

                        if (isPlayerFile) {
                            const json = JsonHandler.parse(text);
                            const deepStore = targetType === 'RP' ? rpDeepMerge : bpDeepMerge;
                            const playerPath = targetType === 'RP' ? 'entity/player.json' : 'entities/player.json';
                            if (!deepStore[playerPath]) {
                                deepStore[playerPath] = json;
                            } else {
                                deepStore[playerPath] = jsonMerger.mergeJsonList([deepStore[playerPath], json], playerPath);
                                for (const entry of jsonMerger.getLogs()) logs.push(entry);
                            }
                            continue;
                        }

                        // Identifier conflict resolution
                        const folder = ConflictDetector.getTopFolder(path);
                        let skipFile = false;
                        for (const id of ids) {
                            // Check user-supplied conflict resolution first
                            const conflictId = folder ? `ID: ${id} (${folder})` : `ID: ${id}`;
                            const legacyConflict = conflicts.find(c => c.type === 'identifier' && c.pathOrId === conflictId && c.category === targetType);
                            if (legacyConflict?.resolved && legacyConflict.resolution?.type === 'keep_one') {
                                if (legacyConflict.resolution.selectedPackId !== pack.id) { skipFile = true; break; }
                            }
                            // IdentifierManager resolution
                            if (!idManager.shouldIncludeDefinition(pack.id, id)) { skipFile = true; break; }
                        }
                        if (skipFile) continue;

                        // MERGE_TARGETS: smart deep merge using UniversalJsonMerger
                        const isMergeTarget = MERGE_TARGETS.some(t => t.toLowerCase() === lowerPath);
                        if (isMergeTarget) {
                            const json = JsonHandler.parse(text);
                            const deepStore = targetType === 'RP' ? rpDeepMerge : bpDeepMerge;
                            if (!deepStore[lowerPath]) {
                                deepStore[lowerPath] = json;
                            } else {
                                deepStore[lowerPath] = jsonMerger.mergeJsonList([deepStore[lowerPath], json], lowerPath);
                                for (const entry of jsonMerger.getLogs()) logs.push(entry);
                            }
                            continue;
                        }

                        // Non-target JSON: check for same-path conflicts and deep merge if possible
                        const targetMap = targetType === 'RP' ? rpFiles : bpFiles;
                        const fileConflict = conflicts.find(c => c.pathOrId === lowerPath && c.category === targetType);

                        if (fileConflict?.resolved) {
                            if (fileConflict.resolution?.type === 'keep_one') {
                                if (fileConflict.resolution.selectedPackId === pack.id) targetMap.set(path, text);
                            } else if (fileConflict.resolution?.type === 'keep_both') {
                                if (!targetMap.has(path)) {
                                    targetMap.set(path, text);
                                } else {
                                    const ext = path.includes('.') ? path.split('.').pop() : '';
                                    const base = path.includes('.') ? path.substring(0, path.lastIndexOf('.')) : path;
                                    targetMap.set(`${base}_${pack.id.substring(0, 4)}.${ext}`, text);
                                }
                            } else if (fileConflict.resolution?.type === 'merge_json') {
                                // Deep merge strategy: accumulate in rpDeepMerge/bpDeepMerge
                                const json = JsonHandler.parse(text);
                                const deepStore = targetType === 'RP' ? rpDeepMerge : bpDeepMerge;
                                if (!deepStore[lowerPath]) {
                                    deepStore[lowerPath] = json;
                                } else {
                                    deepStore[lowerPath] = jsonMerger.mergeJsonList([deepStore[lowerPath], json], lowerPath);
                                    for (const entry of jsonMerger.getLogs()) logs.push(entry);
                                }
                            }
                            continue;
                        }

                        // No explicit resolution — try smart deep merge if path is already taken
                        if (targetMap.has(path)) {
                            const existing = targetMap.get(path);
                            if (typeof existing === 'string') {
                                try {
                                    const existingJson = JsonHandler.parse(existing);
                                    const newJson = JsonHandler.parse(text);
                                    const merged = jsonMerger.mergeJsonList([existingJson, newJson], lowerPath);
                                    for (const entry of jsonMerger.getLogs()) logs.push(entry);
                                    targetMap.set(path, JSON.stringify(merged, null, 2));
                                    log('info', `Deep-merged JSON: ${path}`, path, pack.name);
                                } catch {
                                    log('warning', `Could not deep-merge ${path} — keeping first`, path, pack.name);
                                }
                            }
                        } else {
                            targetMap.set(path, text);
                        }
                        continue;
                    } catch (e: any) {
                        log('warning', `JSON processing error for ${path}: ${e?.message ?? e}`, path, pack.name);
                    }
                }

                // ── .lang files ─────────────────────────────────────────────
                if (lowerPath.endsWith('.lang')) {
                    const langText = new TextDecoder().decode(content);
                    const targetMap = targetType === 'RP' ? rpFiles : bpFiles;
                    const existingLang = (targetMap.get(path) as string) || '';
                    targetMap.set(path, this.mergeLangContent(existingLang, langText));
                    continue;
                }

                // ── Binary / other files ─────────────────────────────────────
                const targetMap2 = targetType === 'RP' ? rpFiles : bpFiles;
                const fileConflict = conflicts.find(c => c.pathOrId === lowerPath && c.category === targetType);
                if (fileConflict?.resolved) {
                    if (fileConflict.resolution?.type === 'keep_one') {
                        if (fileConflict.resolution.selectedPackId === pack.id) targetMap2.set(path, content as any);
                    } else if (fileConflict.resolution?.type === 'keep_both') {
                        if (!targetMap2.has(path)) {
                            targetMap2.set(path, content as any);
                        } else {
                            const ext = path.includes('.') ? path.split('.').pop() : '';
                            const base = path.includes('.') ? path.substring(0, path.lastIndexOf('.')) : path;
                            targetMap2.set(`${base}_${pack.id.substring(0, 4)}.${ext}`, content as any);
                        }
                    }
                    continue;
                }
                if (!targetMap2.has(path)) {
                    if (TextUtility.isTextFile(path)) {
                        const rawText = new TextDecoder().decode(content as Uint8Array);
                        targetMap2.set(path, TextUtility.decodeUnicode(rawText));
                    } else {
                        targetMap2.set(path, content as any);
                    }
                }
            }

            // ── Process deferred entry file ─────────────────────────────────
            if (entryFilePath && entryFileContent !== undefined) {
                let updatedContent = entryFileContent;
                if (renamedScripts.size > 0) {
                    updatedContent = Merger.updateScriptImports(updatedContent, renamedScripts, entryFilePath);
                }
                const path = entryFilePath;
                const ext = path.includes('.') ? path.split('.').pop() : 'js';
                const dir = path.includes('/') ? path.substring(0, path.lastIndexOf('/') + 1) : 'scripts/';
                const renamedPath = `${dir}entry_${packShortId}.${ext}`;
                bpFiles.set(renamedPath, updatedContent);
                const importPath = `./${renamedPath.replace(/^scripts\//, '')}`;
                scriptImports.push(`import "${importPath}";`);
                log('info', `Script entry wrapped: ${renamedPath}`, renamedPath, pack.name);
            }
        }

        // ── 2. Finalise script entry ───────────────────────────────────────
        if (scriptImports.length > 0) {
            bpFiles.set('scripts/merged_entry.js', scriptImports.join('\n'));
        }

        // ── 3. Serialise deep-merged files ────────────────────────────────
        for (const [path, obj] of Object.entries(rpDeepMerge)) rpFiles.set(path, JSON.stringify(obj, null, 2));
        for (const [path, obj] of Object.entries(bpDeepMerge)) bpFiles.set(path, JSON.stringify(obj, null, 2));

        // ── 4. Generate merge log file ────────────────────────────────────
        if (config.generateLog && logs.length > 0) {
            const logContent = this.buildLogFile(logs, packs, config);
            bpFiles.set('merge_log.txt', logContent);
        }

        // ── 5. Fill zips ──────────────────────────────────────────────────
        for (const [path, content] of rpFiles) rpZip.file(path, content as any);
        for (const [path, content] of bpFiles) bpZip.file(path, content as any);

        // ── 6. Manifests ──────────────────────────────────────────────────
        const rpUuid = config.fixedRpUuid || uuidv4();
        const bpUuid = uuidv4();

        const rpManifest: any = {
            format_version: 2,
            header: {
                name: `${config.outputName} [RP]`,
                description: config.outputDescription || 'Merged Resource Pack',
                uuid: rpUuid,
                version: config.version,
                min_engine_version: maxEngineVersion
            },
            modules: [{ type: 'resources', uuid: uuidv4(), version: [1, 0, 0] }],
            dependencies: [{ uuid: bpUuid, version: [1, 0, 0] }]
        };

        const bpManifest: any = {
            format_version: 2,
            header: {
                name: `${config.outputName} [BP]`,
                description: config.outputDescription || 'Merged Behavior Pack',
                uuid: bpUuid,
                version: config.version,
                min_engine_version: maxEngineVersion
            },
            modules: [{ type: 'data', uuid: uuidv4(), version: [1, 0, 0] }],
            dependencies: [{ uuid: rpUuid, version: [1, 0, 0] }]
        };

        if (scriptImports.length > 0) {
            bpManifest.modules.push({
                type: 'script',
                language: 'javascript',
                uuid: uuidv4(),
                entry: 'scripts/merged_entry.js',
                version: [1, 0, 0]
            });
            for (const [mod, ver] of Object.entries(bpDependencies)) {
                bpManifest.dependencies.push({ module_name: mod, version: ver });
            }
        }

        rpZip.file('manifest.json', JSON.stringify(rpManifest, null, 2));
        bpZip.file('manifest.json', JSON.stringify(bpManifest, null, 2));

        // Icons
        const iconPack = packs.find(p => p.icon);
        if (iconPack?.icon) {
            const iconBuffer = Buffer.from(iconPack.icon, 'base64');
            rpZip.file('pack_icon.png', iconBuffer);
            bpZip.file('pack_icon.png', iconBuffer);
        }

        // ── 7. Bundle into .mcaddon ───────────────────────────────────────
        const mcaddonZip = new JSZip();
        const rpBuffer = await rpZip.generateAsync({ type: 'nodebuffer' });
        const bpBuffer = await bpZip.generateAsync({ type: 'nodebuffer' });
        mcaddonZip.file('ResourcePack.mcpack', rpBuffer);
        mcaddonZip.file('BehaviorPack.mcpack', bpBuffer);

        const buffer = await mcaddonZip.generateAsync({ type: 'nodebuffer' });
        return { buffer, logs };
    }

    // ── Private helpers ────────────────────────────────────────────────────────

    private static buildLogFile(logs: MergeLogEntry[], packs: ProcessedPack[], config: MergeConfig): string {
        const lines: string[] = [
            `AutoBE Merge Log`,
            `Generated: ${new Date().toISOString()}`,
            `Output: ${config.outputName}`,
            `Packs merged: ${packs.map(p => p.name).join(', ')}`,
            ``,
            `--- Log Entries (${logs.length}) ---`
        ];
        for (const entry of logs) {
            const prefix = entry.level === 'error' ? '[ERROR]' : entry.level === 'warning' ? '[WARN]' : '[INFO]';
            const pack = entry.packName ? ` [${entry.packName}]` : '';
            const file = entry.file ? ` <${entry.file}>` : '';
            lines.push(`${prefix}${pack}${file} ${entry.message}`);
        }
        return lines.join('\n');
    }

    /** Deep merge, aware of version keys and array_name patterns (from original Merger). */
    private static deepMergeObjects(base: any, update: any): any {
        if (typeof base !== typeof update) return update;
        if (Array.isArray(base) && Array.isArray(update)) {
            const merged = [...base];
            for (const item of update) {
                if (typeof item === 'object' && item !== null && 'array_name' in item) {
                    const op = (item as any).operation;
                    const matchIndex = merged.findIndex(m => m.array_name === item.array_name && (op === undefined || m.operation === op));
                    if (matchIndex !== -1) {
                        if ('value' in item && Array.isArray(item.value)) {
                            let baseVal = merged[matchIndex].value;
                            if (!Array.isArray(baseVal)) baseVal = baseVal ? [baseVal] : [];
                            merged[matchIndex].value = [...baseVal, ...item.value];
                        } else if ('value' in item) {
                            merged[matchIndex].value = this.deepMergeObjects(merged[matchIndex].value, item.value);
                        } else {
                            merged[matchIndex] = this.deepMergeObjects(merged[matchIndex], item);
                        }
                    } else {
                        merged.push(item);
                    }
                } else {
                    merged.push(item);
                }
            }
            return merged;
        } else if (typeof base === 'object' && base !== null && update !== null) {
            const result = { ...base };
            for (const key in update) {
                if (key in result) result[key] = this.deepMergeObjects(result[key], update[key]);
                else result[key] = update[key];
            }
            return result;
        }
        return update;
    }

    private static mergeLangContent(existing: string, incoming: string): string {
        const langMap = new Map<string, string>();
        existing = TextUtility.decodeUnicode(existing);
        incoming = TextUtility.decodeUnicode(incoming);
        const parseLines = (text: string) => {
            text.split(/\r?\n/).forEach(line => {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith('#')) return;
                const eqIndex = trimmed.indexOf('=');
                if (eqIndex !== -1) {
                    const key = trimmed.substring(0, eqIndex).trim();
                    const value = trimmed.substring(eqIndex + 1).trim();
                    if (!langMap.has(key)) langMap.set(key, value);
                }
            });
        };
        parseLines(existing);
        parseLines(incoming);
        let result = '';
        langMap.forEach((value, key) => { result += `${key}=${value}\n`; });
        return result;
    }

    private static updateScriptImports(content: string, renames: Map<string, string>, currentPath: string): string {
        const importRegex = /(import\s+(?:[\w\s{},*]*\s+from\s+)?|(?:export\s+(?:[\w\s{},*]*\s+from\s+)?))([\"'])(.*?)\2/g;
        const currentDir = currentPath.substring(0, currentPath.lastIndexOf('/') + 1);

        return content.replace(importRegex, (match, prefix, quote, path) => {
            let absolutePath = '';
            if (path.startsWith('./') || path.startsWith('../')) {
                const parts = currentDir.split('/').filter((p: string) => p);
                for (const part of path.split('/')) {
                    if (part === '.') continue;
                    if (part === '..') parts.pop();
                    else parts.push(part);
                }
                absolutePath = parts.join('/');
            } else {
                if (!path.startsWith('@') && !path.includes(':')) absolutePath = currentDir + path;
                else return match;
            }
            absolutePath = absolutePath.replace(/\\/g, '/');
            const newPath = renames.get(absolutePath) || renames.get(absolutePath + '.js') || renames.get(absolutePath + '.ts');
            if (newPath) {
                const newFilename = newPath.substring(newPath.lastIndexOf('/') + 1);
                const lastSlash = path.lastIndexOf('/');
                if (lastSlash !== -1) return `${prefix}${quote}${path.substring(0, lastSlash + 1)}${newFilename}${quote}`;
                if (path.startsWith('./')) return `${prefix}${quote}./${newFilename}${quote}`;
                return `${prefix}${quote}${newFilename}${quote}`;
            }
            return match;
        });
    }
}
