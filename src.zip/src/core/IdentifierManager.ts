import { ProcessedPack, MergeLogEntry } from './types';
import { JsonHandler } from './JsonHandler';

interface IdentifierSet {
    entities: Set<string>;
    items: Set<string>;
    blocks: Set<string>;
    loot_tables: Set<string>;
    recipes: Set<string>;
    animation_controllers: Set<string>;
    render_controllers: Set<string>;
    textures: Set<string>;
}

/**
 * Manages identifier scanning, conflict detection, and resolution across packs.
 * Ported from AutoBE.py's IdentifierManager.
 */
export class IdentifierManager {
    /** identifier -> set of packIds that define it */
    private conflictMap = new Map<string, Set<string>>();
    /** packId -> identifier sets by type */
    private packIdentifiers = new Map<string, IdentifierSet>();
    /** (packId, oldId) -> newId  — currently identity (no rename); filtering done by shouldInclude */
    private identifierMapping = new Map<string, string>();
    /** identifier -> packId to keep (undefined = keep all) */
    private userResolution = new Map<string, string | undefined>();

    private warnings: string[] = [];

    // ── Scanning ──────────────────────────────────────────────────────────────

    async scanPack(pack: ProcessedPack): Promise<IdentifierSet> {
        const ids: IdentifierSet = {
            entities: new Set(),
            items: new Set(),
            blocks: new Set(),
            loot_tables: new Set(),
            recipes: new Set(),
            animation_controllers: new Set(),
            render_controllers: new Set(),
            textures: new Set()
        };

        for (const [path, zipObj] of pack.files) {
            const lp = path.toLowerCase();
            if (lp.startsWith('subpacks/')) continue;
            try {
                if (lp.startsWith('entities/') && lp.endsWith('.json')) {
                    const text = await zipObj.async('string');
                    for (const id of this._extractEntityIds(text)) ids.entities.add(id);
                } else if (lp.startsWith('items/') && lp.endsWith('.json')) {
                    const text = await zipObj.async('string');
                    for (const id of this._extractItemIds(text)) ids.items.add(id);
                } else if (lp.startsWith('blocks/') && lp.endsWith('.json')) {
                    const text = await zipObj.async('string');
                    for (const id of this._extractBlockIds(text)) ids.blocks.add(id);
                } else if (lp.startsWith('loot_tables/') && lp.endsWith('.json')) {
                    const id = this._lootTablePathToId(path);
                    if (id) ids.loot_tables.add(id);
                } else if (lp.startsWith('recipes/') && lp.endsWith('.json')) {
                    const text = await zipObj.async('string');
                    for (const id of this._extractRecipeIds(text)) ids.recipes.add(id);
                } else if (lp.includes('animation_controllers') && lp.endsWith('.json')) {
                    const text = await zipObj.async('string');
                    for (const id of this._extractMappedIds(text, 'animation_controllers')) ids.animation_controllers.add(id);
                } else if (lp.includes('render_controllers') && lp.endsWith('.json')) {
                    const text = await zipObj.async('string');
                    for (const id of this._extractMappedIds(text, 'render_controllers')) ids.render_controllers.add(id);
                }
            } catch { /* non-fatal */ }
        }

        this.packIdentifiers.set(pack.id, ids);
        return ids;
    }

    async detectConflicts(packs: ProcessedPack[]): Promise<void> {
        // Scan all packs if not already done
        for (const pack of packs) {
            if (!this.packIdentifiers.has(pack.id)) await this.scanPack(pack);
        }

        // Build conflict map
        for (const [packId, idSet] of this.packIdentifiers) {
            for (const [typeName, set] of Object.entries(idSet)) {
                for (const id of set) {
                    const ns = id.includes(':') ? id.split(':')[0] : '';
                    if (ns === 'minecraft' || ns === 'loot_tables') continue;
                    if (!this.conflictMap.has(id)) this.conflictMap.set(id, new Set());
                    this.conflictMap.get(id)!.add(packId);
                }
            }
        }
    }

    /** Return list of [identifier, packIds[]] for identifiers with real conflicts. */
    getConflictList(packs: ProcessedPack[]): Array<{ identifier: string; packIds: string[] }> {
        const idToPack = new Map(packs.map(p => [p.id, p]));
        const results: Array<{ identifier: string; packIds: string[] }> = [];

        for (const [identifier, packIdSet] of this.conflictMap) {
            if (packIdSet.size <= 1) continue;

            // Ignore false conflicts where every pack is a BP/RP half of the same addon
            const baseNames = new Set([...packIdSet].map(pid => {
                const p = idToPack.get(pid);
                return p ? this._packBaseName(p.fileName) : pid;
            }));
            if (baseNames.size === 1) continue;

            results.push({ identifier, packIds: [...packIdSet] });
        }
        return results;
    }

    setUserResolution(identifier: string, packId: string | undefined): void {
        this.userResolution.set(identifier, packId);
    }

    shouldIncludeDefinition(packId: string, identifier: string): boolean {
        if (!this.userResolution.has(identifier)) return true;
        const keep = this.userResolution.get(identifier);
        if (keep === undefined) return true;
        return packId === keep;
    }

    generateMappings(): void {
        for (const [identifier, packIdSet] of this.conflictMap) {
            if (packIdSet.size <= 1) continue;
            const keepPack = this.userResolution.get(identifier);
            if (keepPack !== undefined) {
                for (const packId of packIdSet) {
                    this.identifierMapping.set(`${packId}::${identifier}`, identifier);
                }
            }
            // keep-all (undefined): no rename; deep-merge handles it
        }
    }

    getNewIdentifier(packId: string, oldId: string): string {
        return this.identifierMapping.get(`${packId}::${oldId}`) ?? oldId;
    }

    hasConflict(identifier: string): boolean {
        return (this.conflictMap.get(identifier)?.size ?? 0) > 1;
    }

    getLogs(): MergeLogEntry[] {
        return this.warnings.map(w => ({ level: 'warning' as const, message: w }));
    }

    // ── Private extractors ────────────────────────────────────────────────────

    private _extractEntityIds(text: string): string[] {
        try {
            const data = JsonHandler.tryParse<any>(text);
            if (!data) return [];
            const ids: string[] = [];
            for (const key of ['minecraft:entity', 'minecraft:client_entity']) {
                if (data[key]?.description?.identifier) {
                    const id: string = data[key].description.identifier;
                    if (id !== 'minecraft:player') ids.push(id);
                }
            }
            return ids;
        } catch { return []; }
    }

    private _extractItemIds(text: string): string[] {
        try {
            const data = JsonHandler.tryParse<any>(text);
            const id = data?.['minecraft:item']?.description?.identifier;
            return id ? [id] : [];
        } catch { return []; }
    }

    private _extractBlockIds(text: string): string[] {
        try {
            const data = JsonHandler.tryParse<any>(text);
            const id = data?.['minecraft:block']?.description?.identifier;
            return id ? [id] : [];
        } catch { return []; }
    }

    private _lootTablePathToId(path: string): string | null {
        if (!path.toLowerCase().startsWith('loot_tables/')) return null;
        const part = path.slice('loot_tables/'.length).replace(/\.json$/i, '');
        const parts = part.split('/');
        if (parts.length >= 2) return `${parts[0]}:${parts.slice(1).join('/')}`;
        if (parts.length === 1) return `loot_tables:${parts[0]}`;
        return null;
    }

    private _extractRecipeIds(text: string): string[] {
        try {
            const data = JsonHandler.tryParse<any>(text);
            if (!data) return [];
            const ids: string[] = [];
            for (const key of Object.keys(data)) {
                if (key.toLowerCase().includes('recipe')) {
                    const id = data[key]?.description?.identifier;
                    if (id) ids.push(id);
                }
            }
            return ids;
        } catch { return []; }
    }

    private _extractMappedIds(text: string, section: string): string[] {
        try {
            const data = JsonHandler.tryParse<any>(text);
            if (!data || !data[section]) return [];
            return Object.keys(data[section]).filter(k => k.includes(':'));
        } catch { return []; }
    }

    /** Strip AutoBE-style suffixes from a filename for same-addon detection. */
    private _packBaseName(fileName: string): string {
        let name = fileName.replace(/\.(mcpack|mcaddon)$/i, '');
        name = name.replace(/_modified$/i, '');
        name = name.replace(/_\d+$/, '');
        name = name.replace(/[\-_\s]*(bp|rp|behaviors?|resources?|behavior[_\-]?pack|resource[_\-]?pack)$/i, '');
        return name.toLowerCase();
    }
}
