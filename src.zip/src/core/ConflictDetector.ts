import type { ProcessedPack, Conflict } from './types';
import { MERGE_TARGETS } from './types';
import { v4 as uuidv4 } from 'uuid';
import { JsonHandler } from './JsonHandler';
import { TextUtility } from './TextUtility';
import { IdentifierManager } from './IdentifierManager';

export class ConflictDetector {
    static resolveLinks(packs: ProcessedPack[]) {
        const uuidToPack = new Map<string, ProcessedPack>();
        for (const pack of packs) uuidToPack.set(pack.manifest.header.uuid, pack);

        for (const pack of packs) {
            if (pack.manifest.dependencies) {
                for (const dep of pack.manifest.dependencies) {
                    if (dep.uuid && uuidToPack.has(dep.uuid)) {
                        const target = uuidToPack.get(dep.uuid)!;
                        const isBP = pack.type.includes('behavior') || pack.type.includes('script');
                        const targetIsRP = target.type.includes('resource');
                        const isRP = pack.type.includes('resource');
                        const targetIsBP = target.type.includes('behavior') || target.type.includes('script');

                        if ((isBP && targetIsRP) || (isRP && targetIsBP)) {
                            pack.linkedPackId = target.id;
                            target.linkedPackId = pack.id;
                        }
                    }
                }
            }
        }
    }

    static async detect(packs: ProcessedPack[]): Promise<Conflict[]> {
        const conflicts: Conflict[] = [];

        const bpPacks = packs.filter(p => p.type.includes('behavior') || p.type.includes('script'));
        const rpPacks = packs.filter(p => p.type.includes('resource'));

        // 1. File conflicts
        conflicts.push(...await this.detectFileConflicts(bpPacks, 'BP'));
        conflicts.push(...await this.detectFileConflicts(rpPacks, 'RP'));

        // 2. Identifier conflicts (enhanced via IdentifierManager)
        conflicts.push(...await this.detectIdentifierConflictsEnhanced(bpPacks, 'BP'));
        conflicts.push(...await this.detectIdentifierConflictsEnhanced(rpPacks, 'RP'));

        // 3. Obfuscation detection (AutoBE: flag obfuscated packs)
        for (const pack of packs) {
            if (pack.obfuscated) {
                conflicts.push({
                    id: uuidv4(),
                    type: 'obfuscated',
                    pathOrId: `Pack is obfuscated: ${pack.name}`,
                    sources: [{ packId: pack.id, packName: pack.name }],
                    resolved: false
                });
            }
        }

        // 4. Achievement-disabling detection (AutoBE)
        const achievementPacks = packs.filter(p => p.disablesAchievements);
        if (achievementPacks.length > 0) {
            conflicts.push({
                id: uuidv4(),
                type: 'achievement',
                pathOrId: 'Achievement Compatibility — these packs disable achievements',
                sources: achievementPacks.map(p => ({
                    packId: p.id,
                    packName: p.name,
                    value: (p.manifest.capabilities ?? []).join(', ')
                })),
                resolved: false
            });
        }

        // 5. Engine version generation mismatches
        const generations = new Map<string, ProcessedPack[]>();
        for (const pack of packs) {
            const ev = pack.manifest.header.min_engine_version;
            if (ev) {
                const gen = `${ev[0]}.${ev[1]}`;
                if (!generations.has(gen)) generations.set(gen, []);
                generations.get(gen)!.push(pack);
            }
        }
        if (generations.size > 1) {
            conflicts.push({
                id: uuidv4(),
                type: 'version',
                pathOrId: 'Engine Version Generation Mismatch',
                sources: Array.from(generations.entries()).flatMap(([gen, gPacks]) =>
                    gPacks.map(p => ({ packId: p.id, packName: p.name, value: `Targeting ${gen}.x` }))
                ),
                resolved: false
            });
        }

        // 6. Script dependency mismatches (version-aware)
        const depMap = new Map<string, Map<string, ProcessedPack[]>>();
        for (const pack of packs) {
            if (pack.manifest.dependencies) {
                for (const dep of pack.manifest.dependencies) {
                    if (dep.module_name && dep.module_name.startsWith('@minecraft/')) {
                        const module = dep.module_name;
                        const fullVersion = Array.isArray(dep.version)
                            ? dep.version.join('.')
                            : (dep.version || '0.0.0').toString();
                        if (!depMap.has(module)) depMap.set(module, new Map());
                        const versions = depMap.get(module)!;
                        if (!versions.has(fullVersion)) versions.set(fullVersion, []);
                        versions.get(fullVersion)!.push(pack);
                    }
                }
            }
        }
        for (const [module, versions] of depMap) {
            if (versions.size > 1) {
                const majorVersions = new Set(Array.from(versions.keys()).map(v => v.split('.')[0]));
                const isCritical = majorVersions.size > 1;
                conflicts.push({
                    id: uuidv4(),
                    type: 'dependency',
                    pathOrId: `${isCritical ? 'CRITICAL: ' : ''}Script Dependency Mismatch: ${module}`,
                    sources: Array.from(versions.entries()).flatMap(([version, vPacks]) =>
                        vPacks.map(p => ({ packId: p.id, packName: p.name, value: `Uses v${version}` }))
                    ),
                    resolved: false
                });
            }
        }

        return conflicts;
    }

    private static async detectFileConflicts(packs: ProcessedPack[], category: 'BP' | 'RP'): Promise<Conflict[]> {
        const conflicts: Conflict[] = [];
        const fileMap = new Map<string, ProcessedPack[]>();

        for (const pack of packs) {
            for (const path of pack.files.keys()) {
                const normalizedPath = path.toLowerCase();
                if (['manifest.json', 'pack_icon.png', 'pack_icon.json'].includes(normalizedPath)) continue;
                if (normalizedPath.endsWith('.lang')) continue;
                if (MERGE_TARGETS.includes(normalizedPath)) continue;

                const scriptEntry = pack.manifest.modules.find((m: any) => m.type === 'script')?.entry || 'scripts/main.js';
                if (normalizedPath === scriptEntry.toLowerCase().replace(/\\/g, '/')) continue;

                if (!fileMap.has(normalizedPath)) fileMap.set(normalizedPath, []);
                fileMap.get(normalizedPath)!.push(pack);
            }
        }

        for (const [path, packsWithFile] of fileMap.entries()) {
            if (packsWithFile.length <= 1) continue;

            // Check if identical
            let areIdentical = true;
            const firstPack = packsWithFile[0];
            const firstKey = Array.from(firstPack.files.keys()).find((k: string) => k.toLowerCase() === path);
            if (!firstKey) continue;
            const firstData = await firstPack.files.get(firstKey)?.async('uint8array');

            for (let i = 1; i < packsWithFile.length; i++) {
                const realKey = Array.from(packsWithFile[i].files.keys()).find((k: string) => k.toLowerCase() === path);
                if (!realKey) continue;
                const data = await packsWithFile[i].files.get(realKey)?.async('uint8array');
                if (!firstData || !data || !this.compareArrays(firstData, data)) {
                    areIdentical = false;
                    break;
                }
            }

            if (!areIdentical) {
                const sourceInfos = [];
                const allIds = new Set<string>();
                let idsOverlap = false;
                let isPlayerConflict = false;

                for (const pack of packsWithFile) {
                    const realKey = Array.from(pack.files.keys()).find((k: string) => k.toLowerCase() === path);
                    if (!realKey) continue;
                    const content = await pack.files.get(realKey)!.async('uint8array');
                    const text = TextUtility.decodeUnicode(new TextDecoder().decode(content));
                    const ids = this.extractIdentifiers(text, path);
                    if (ids.includes('minecraft:player')) isPlayerConflict = true;
                    sourceInfos.push({ packId: pack.id, packName: pack.name, ids });
                    for (const id of ids) {
                        if (id === 'minecraft:player') continue;
                        if (allIds.has(id)) idsOverlap = true;
                        allIds.add(id);
                    }
                }

                if (isPlayerConflict && sourceInfos.every(s => s.ids && s.ids.length === 1 && s.ids[0] === 'minecraft:player')) continue;

                conflicts.push({
                    id: uuidv4(),
                    type: path.endsWith('.json') || path.endsWith('.lang') ? 'file_content' : 'file_binary',
                    pathOrId: path,
                    category,
                    sources: sourceInfos,
                    resolved: false,
                    idsOverlap
                });
            }
        }
        return conflicts;
    }

    /** Enhanced identifier detection using IdentifierManager (covers entities, items, blocks, recipes, loot tables, etc.) */
    private static async detectIdentifierConflictsEnhanced(packs: ProcessedPack[], category: 'BP' | 'RP'): Promise<Conflict[]> {
        const conflicts: Conflict[] = [];
        const manager = new IdentifierManager();

        for (const pack of packs) await manager.scanPack(pack);
        await manager.detectConflicts(packs);

        const conflictList = manager.getConflictList(packs);
        const packIdToName = new Map(packs.map(p => [p.id, p.name]));

        for (const { identifier, packIds } of conflictList) {
            conflicts.push({
                id: uuidv4(),
                type: 'identifier',
                pathOrId: `ID: ${identifier}`,
                category,
                sources: packIds.map(pid => ({
                    packId: pid,
                    packName: packIdToName.get(pid) ?? pid
                })),
                resolved: false
            });
        }

        // Also run existing folder-based detection for completeness
        const legacy = await this.detectIdentifierConflicts(packs, category);
        // Deduplicate by pathOrId
        const existingPaths = new Set(conflicts.map(c => c.pathOrId));
        for (const c of legacy) {
            if (!existingPaths.has(c.pathOrId)) conflicts.push(c);
        }

        return conflicts;
    }

    private static async detectIdentifierConflicts(packs: ProcessedPack[], category: 'BP' | 'RP'): Promise<Conflict[]> {
        const conflicts: Conflict[] = [];
        const folderIdMap = new Map<string, Map<string, { packId: string; packName: string; file: string }[]>>();

        for (const pack of packs) {
            for (const [path, zipObj] of pack.files) {
                const lowerPath = path.toLowerCase();
                if (!lowerPath.endsWith('.json')) continue;
                const folder = this.getTopFolder(path);
                if (!folder) continue;

                const content = await zipObj.async('uint8array');
                const text = TextUtility.decodeUnicode(new TextDecoder().decode(content));
                const ids = this.extractIdentifiers(text, path);

                if (!folderIdMap.has(folder)) folderIdMap.set(folder, new Map());
                const idMap = folderIdMap.get(folder)!;

                for (const id of ids) {
                    if (id === 'minecraft:player') continue;
                    if (!idMap.has(id)) idMap.set(id, []);
                    idMap.get(id)!.push({ packId: pack.id, packName: pack.name, file: path });
                }
            }
        }

        for (const [folder, idMap] of folderIdMap) {
            for (const [id, occurrences] of idMap) {
                const packsInvolved = new Set(occurrences.map(o => o.packId));
                if (packsInvolved.size > 1) {
                    conflicts.push({
                        id: uuidv4(),
                        type: 'identifier',
                        pathOrId: `ID: ${id} (${folder})`,
                        category,
                        sources: occurrences.map(o => ({ packId: o.packId, packName: o.packName, value: o.file })),
                        resolved: false
                    });
                }
            }
        }
        return conflicts;
    }

    public static getTopFolder(path: string): string | null {
        const parts = path.split(/[\\\/]/);
        return parts.length > 1 ? parts[0].toLowerCase() : null;
    }

    public static extractIdentifiers(text: string, path: string): string[] {
        const ids: string[] = [];
        try {
            const json = JsonHandler.tryParse(text);
            if (!json) return ids;
            const lowerPath = path.toLowerCase();

            const mappedFolders = ['animations', 'animation_controllers', 'render_controllers', 'particles', 'attachables'];
            const folderMatch = mappedFolders.find(f => lowerPath.includes(`${f}/`));
            if (folderMatch && json[folderMatch]) {
                ids.push(...Object.keys(json[folderMatch]));
            }

            const scanForIdentifier = (obj: any) => {
                if (!obj || typeof obj !== 'object') return;
                if (obj.description && typeof obj.description.identifier === 'string') ids.push(obj.description.identifier);
                for (const key in obj) {
                    if (obj[key] && typeof obj[key] === 'object') {
                        if (obj[key].description?.identifier && typeof obj[key].description.identifier === 'string') {
                            ids.push(obj[key].description.identifier);
                        }
                    }
                }
            };
            scanForIdentifier(json);
        } catch { }
        return Array.from(new Set(ids));
    }

    static analyzeCompatibility(packs: ProcessedPack[]) {
        if (packs.length <= 1) return null;

        const bpPacks = packs.filter(p => p.type.includes('behavior') || p.type.includes('script'));
        const rpPacks = packs.filter(p => p.type.includes('resource'));

        const findGroups = (group: ProcessedPack[]) => {
            if (group.length === 0) return [];
            const genGroups = new Map<string, ProcessedPack[]>();
            for (const pack of group) {
                const ev = pack.manifest.header.min_engine_version;
                const gen = ev ? `${ev[0]}.${ev[1]}` : 'unknown';
                if (!genGroups.has(gen)) genGroups.set(gen, []);
                genGroups.get(gen)!.push(pack);
            }

            const results = [];
            for (const [gen, gPacks] of genGroups) {
                let remaining = [...gPacks];
                while (remaining.length > 0) {
                    const currentGroup: ProcessedPack[] = [];
                    const masterDeps = new Map<string, string>();
                    const nextRemaining: ProcessedPack[] = [];

                    for (const pack of remaining) {
                        let isCompatible = true;
                        if (pack.manifest.dependencies) {
                            for (const dep of pack.manifest.dependencies) {
                                if (dep.module_name) {
                                    const fullVer = Array.isArray(dep.version) ? dep.version.join('.') : (dep.version || '0.0.0').toString();
                                    const majorVer = fullVer.split('.')[0];
                                    if (masterDeps.has(dep.module_name) && masterDeps.get(dep.module_name) !== majorVer) {
                                        isCompatible = false;
                                        break;
                                    }
                                }
                            }
                        }
                        if (isCompatible) {
                            currentGroup.push(pack);
                            if (pack.manifest.dependencies) {
                                for (const dep of pack.manifest.dependencies) {
                                    if (dep.module_name) {
                                        const fullVer = Array.isArray(dep.version) ? dep.version.join('.') : (dep.version || '0.0.0').toString();
                                        masterDeps.set(dep.module_name, fullVer.split('.')[0]);
                                    }
                                }
                            }
                        } else {
                            nextRemaining.push(pack);
                        }
                    }
                    if (currentGroup.length > 0) results.push({ generation: gen, packs: currentGroup });
                    remaining = nextRemaining;
                }
            }
            return results.sort((a, b) => b.packs.length - a.packs.length);
        };

        return { bp: findGroups(bpPacks), rp: findGroups(rpPacks) };
    }

    static groupPacksForCompatibility(packs: ProcessedPack[]) {
        const rps = packs.filter(p => p.type.includes('resource'));
        const bps = packs.filter(p => p.type.includes('behavior') || p.type.includes('script'));

        const scriptlessBps: ProcessedPack[] = [];
        const scriptedBps: ProcessedPack[] = [];

        for (const bp of bps) {
            const hasScript = bp.type.includes('script') || (bp.manifest.modules?.some((m: any) => m.type === 'script'));
            if (hasScript) scriptedBps.push(bp);
            else scriptlessBps.push(bp);
        }

        const scriptVersions: Record<string, ProcessedPack[]> = {};
        for (const bp of scriptedBps) {
            let version = 'unknown';
            if (bp.manifest.dependencies) {
                for (const dep of bp.manifest.dependencies) {
                    if (dep.module_name === '@minecraft/server') {
                        const v = Array.isArray(dep.version) ? dep.version : (typeof dep.version === 'string' ? dep.version.split('.') : null);
                        if (v) { version = `${v[0]}.x.x`; break; }
                    }
                }
            }
            if (!scriptVersions[version]) scriptVersions[version] = [];
            scriptVersions[version].push(bp);
        }

        return { universalGroup: { rps, scriptlessBps }, scriptGroups: scriptVersions };
    }

    private static compareArrays(a: Uint8Array, b: Uint8Array): boolean {
        if (a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
        return true;
    }
}
