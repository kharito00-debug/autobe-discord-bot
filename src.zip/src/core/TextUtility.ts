export class TextUtility {
    /**
     * Decodes all \uXXXX Unicode escape sequences into normal text.
     */
    static decodeUnicode(str: string): string {
        return str.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => {
            return String.fromCharCode(parseInt(hex, 16));
        });
    }

    /**
     * Checks if a file is likely obfuscated based on Unicode escape density.
     */
    static isObfuscated(text: string): boolean {
        const unicodeCount = (text.match(/\\u[0-9a-fA-F]{4}/g) || []).length;
        // Threshold: More than 40 unicode escapes often indicates obfuscation in MC packs
        return unicodeCount > 40;
    }

    /**
     * Determines if a file extension/path belongs to a text-based file.
     */
    static isTextFile(path: string): boolean {
        const lower = path.toLowerCase();
        return (
            lower.endsWith('.json') ||
            lower.endsWith('.lang') ||
            lower.endsWith('.js') ||
            lower.endsWith('.ts') ||
            lower.endsWith('.txt') ||
            lower.endsWith('.mcfunction')
        );
    }
}
